SOURCE: http://www.caiso.com/TodaysOutlook/Pages/Supply.aspx
Renewables trend download