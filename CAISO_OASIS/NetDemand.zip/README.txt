SOURCE: http://www.caiso.com/TodaysOutlook/Pages/default.aspx
Net demand data download